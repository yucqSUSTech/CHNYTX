function [ takeoff ] = takeoffang( vel_model, evdp, phase, gcarc, mohodepth, vp_upmantle )
%TAKEOFFANG Summary of this function goes here
%   Detailed explanation goes here

% this program is aimed to calculate takeoff angle for given epicenter
% distance stations, the depth of the event is also an input parameter.
% using ray shooting method to calculate the epicenter distance for each
% take off angle, and then for the given epicenter distance, interpolate the
% take off angle. If there is low velocity zone in the velocity model,
% there might be mulipathing...

% INPUT:
% phase: phase name, should be one of the 'p','P','Pn'.(So far I only use
%        these three phases to calculate focal mechanisms.
% velmodel: velocity model, each line define the depth of the upper limit
% of the layer, Vp, Vs, and density.
% evdp: event depth (in km)
% gcarc: epicenter distance (great arc distance, in deg)
% 

% teleseismic P wave, stations epicenter distance range
tgcarc_range = [10, 180];

% takeoff angle for ray shooting
dtheta = 0.1;
toa = dtheta:dtheta:180; % the angle between ray takeoff direction and the downward direction (point to the earth center)

% load in velocity model
[depth, vp, vs, rho] = textread(vel_model,'%f %f %f %f','commentstyle','shell');

% find the layer where the event locates
R = max(max(depth),6371);
if evdp >= R
    fprintf('Event depth is larger than earth radius, please check evdp (km)!\n');
    return;
end
elayer = 0;
while( evdp > depth(elayer+1) )
    elayer = elayer + 1;
    if elayer+1 > length(depth)
        break;
    end
end
if elayer == 0
    fprintf('evdp <= 0, set to 0!\n');
    elayer = 1;
end

vp_ev = vp(elayer); % velocity of the layer where the earthquake locates
% vs_ev = vs(elayer);


for i = 1:length(toa)
    rayp = (R-evdp)*sin(pi*toa(i)/180)/vp_ev; % P wave ray parameter
    % find the deepest ray turning point and layer number
    if toa(i) >= 90
        tdepth(i) = evdp;
        tlayer(i) = elayer;
    else    
        for j = 1:length(depth)
            rayp1 = (R-depth(j))/vp(j); % theta = 90;
            if j == length(depth)
                depth2 = R;
                rayp2 = 0;
            else
                depth2 = depth(j+1);
                rayp2 = (R-depth2)/vp(j);
            end
            if rayp1 > rayp && rayp2 <= rayp && depth2 > evdp
                tlayer(i) = j; % layer where the turning point locates
                tdepth(i) = R-rayp*vp(tlayer(i)); % calculate the turning point depth
                break;
            elseif rayp1 < rayp && depth2 > evdp
                tlayer(i) = j-1;
                tdepth(i) = depth(j);
                break;
            end
        end
        
        
    end
    

    
    % calculate the epicenter distance for all ray-parameters, and travel
    % time.
    % first the downward part
    epi_down = 0; 
    tt_down = 0;
    
    for k = elayer:1:tlayer(i)
        if k == tlayer(i) 
            zlower = tdepth(i);
        else
            zlower = depth(k+1);
        end
        
        if k == elayer
            zupper = evdp;
        else
            zupper = depth(k);
        end
        
        epi_down = epi_down + ( asin(rayp*vp(k)/(R-zlower)) - asin(rayp*vp(k)/(R-zupper)) ) * 180/pi;
        tt_down = tt_down + 1/vp(k) * ( sqrt((R-zupper)^2-(rayp*vp(k))^2) - sqrt((R-zlower)^2-(rayp*vp(k))^2) ); 
        
    end
    
    % second the upward part
    epi_up = 0;
    tt_up = 0;
    
    for k = tlayer(i):-1:1  
        if k == tlayer(i)
            zlower = tdepth(i);
        else
            zlower = depth(k+1);
        end
        
        zupper = depth(k); % assume the station is located at the surface (layer 1)
        
        epi_up = epi_up + ( asin(rayp*vp(k)/(R-zlower)) - asin(rayp*vp(k)/(R-zupper)) ) * 180/pi;
        tt_up = tt_up + 1/vp(k) * ( sqrt((R-zupper)^2-(rayp*vp(k))^2) - sqrt((R-zlower)^2-(rayp*vp(k))^2) ); 
    end
    
    epi(i) = abs(epi_down + epi_up);
    tt(i) = abs(tt_down + tt_up);
    
end

% get the take off angle for given phases and epicenter distances
for m = 1:length(phase)
    if strcmp(phase(m),'p')  % up going P wave, take off angle larger than 90
        toa_p = 90:dtheta:180;
        epi_p = interp1(toa,epi,toa_p);
        if gcarc(m) < min(epi_p) || gcarc(m) > max(epi_p)
            fprintf('Warning! No phase p for given epicenter distance %f and event depth %f, set takeoff angle to be 90 deg\n', gcarc(m), evdp);
            takeoff(m) = 90;
        else
            [cmin,ind] = min(abs(epi_p-gcarc(m)));
            takeoff(m) = toa_p(ind);
        end
    elseif strcmp(phase(m),'Pn') % head wave
        if evdp > mohodepth
            fprintf('Warning! Event is beneath the Moho, No phase Pn, set take off angle NaN!\n');
            takeoff(m) = NaN;
        else
            takeoff(m) = 180/pi * asin(vp_ev/vp_upmantle * (R-mohodepth)/(R-evdp));
        end
    elseif strcmp(phase(m),'P') % teleseismic P wave
        if gcarc < tgcarc_range(1) || gcarc > tgcarc_range(2)
            fprintf('Warning! Teleseismic P phase is not set for epicenter distance %f and event depth %f, set take off angle NaN!\n', gcarc(m), evdp);
            takeoff(m) = NaN;
        else
            num = 1;
            av_ind = [];
            for n = 1:length(toa)-1
                if (epi(n+1)-gcarc)*(epi(n)-gcarc) <= 0
                    av_ind(num) = n;
                    num = num + 1;
                end
            end
            takeoff(m) = mean(toa(av_ind));
        end
    else
        fprintf('Warning: No %s phase in this program! set take off angle NaN\n',phase(m));
        takeoff(m) = NaN;
    end
end


end
