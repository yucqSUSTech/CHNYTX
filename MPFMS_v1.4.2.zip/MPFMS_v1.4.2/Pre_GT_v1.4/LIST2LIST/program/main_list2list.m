function [ ] = main_list2list( )
%MAIN_LIST2LIST Summary of this function goes here
%   Detailed explanation goes here

% this program is aimed to convert from datalist 1 to datalist 2
% datalist 1
% format:  (each line)
% station_name   network_name   station_latitude  station_longitude   station_elevation   event_latitude   event_longitude  event_depth  P_polarity
% datalist 2
% format:  (each line)
% station_name.network_name   azimuth   takeoff_angle   P_polarity
% 
% datalist 2 is the format needed as input file for the program PKU_Grid_Test
% you can deal with several datalist 1 at the same time
%%

input_list_path = [pwd,'/../input_list'] ;%store datalist 1 
output_list_path = [pwd,'/../output_list'];%store datalist 2
vel_model = 'vel_model.txt';%ray path velocity model, can be 'iasp91', 'prem', 'ak135' and so on (see taup manual for detail). here, i use my own vel model created by taup_create command. no extension name!
ID = '*.txt'; %recognize files which need to be converted
   
% the following two parameters are used for calculating takeoff angle of
% head waves. It can be the same as the value in the velocity model.
mohodepth = 35; % events below this depth don't have head waves
vp_upmantle = 8.1;


%% main program
if ~exist(output_list_path,'dir')
    mkdir(output_list_path);
end

events = dir([input_list_path,'/',ID]);
nevents = size(events,1);
for i = 1:nevents
    [pathstr,listname,]=fileparts(events(i).name);
    [stname, netwk, stla, stlo, stel, evla, evlo, evdp, IP]=textread([input_list_path,'/',events(i).name],'%s %s %f %f %f %f %f %f %s');%read in datalist 1
    fid = fopen([output_list_path,'/',listname,'.dat'],'w');
    nsta = size(stla,1);
    for j =1:nsta
        [ gcarc, azimuth, ] = edist(evla(j),evlo(j),stla(j),stlo(j));
        abs_ip = abs(str2num(char(IP(j))));
        if abs_ip == 1 || abs_ip == 11
            phase = {'p'};
        elseif abs_ip == 2 || abs_ip == 22
            phase = {'Pn'};
        elseif abs_ip == 5 || abs_ip == 55
            phase = {'P'};
        else
            fprintf('Error! Wrong phase name!\n');
            return;
        end
        
       [ takeoff ] = takeoffang( vel_model, evdp(j), phase, gcarc, mohodepth, vp_upmantle );
       fprintf(fid,'%s %f %f %s\n',[char(stname(j)),'.',char(netwk(j))],azimuth, takeoff ,char(IP(j)));
    end
    fclose(fid);
end
end