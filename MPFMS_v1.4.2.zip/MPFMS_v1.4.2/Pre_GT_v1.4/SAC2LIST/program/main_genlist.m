function [ ] = main_genlist( )
%MAIN_GENLIST Summary of this function goes here
%   Detailed explanation goes here

%%
% this program is aimed to generate datalist 1 from sac files, which have
% been selected by program select_polarity.csh
% datalist 1
% format:  (each line)
% station_name   network_name   station_latitude  station_longitude station_elevation   event_latitude   event_longitude  event_depth  P_polarity
% so sacfiles' header must contain these information

dirpath = '../workdir/Good' ;
ofilepath = '../lists';
if ~exist(ofilepath,'dir')
    mkdir(ofilepath);
end

ID = '*'; %recognize events
eventdirs = dir([dirpath,'/',ID,'*']);
nevents = size(eventdirs,1);

for i = 1:nevents
    fid = fopen([ofilepath,'/',eventdirs(i).name,'.txt'],'w');
    polardirs = dir([dirpath,'/', eventdirs(i).name]);    
    npolars = size(polardirs,1);    
    for j = 1:npolars        
        
        files = dir([dirpath,'/', eventdirs(i).name,'/',polardirs(j).name,'/*.z*']);
        nfiles = size(files,1);
        for p = 1:nfiles            
            filename = files(p).name;          
            header = irdsachd([dirpath,'/', eventdirs(i).name,'/',polardirs(j).name,'/',filename]);
            stnm = deblank(header.kstnm);
            netwk = deblank(header.knetwk);
            stla = header.stla;
            stlo = header.stlo;
            stel = header.stel;
            evla = header.evla;
            evlo = header.evlo;
            evdp = header.evdp;
            if evdp >=1000		% in case the unit of event depth is "m"
            		evdp = evdp/1000;
            end      
            fprintf(fid,'%s  %s  %f  %f  %f  %f  %f  %f  %s\n',stnm , netwk , stla , stlo , stel , evla , evlo , evdp , polardirs(j).name);
        end
    end

    fclose(fid);
%    movefile([dirpath,'/', eventdirs(i).name],[dirpath,'/Done.', eventdirs(i).name],'f');
    fprintf(1,'%s is Done\n',eventdirs(i).name);
end

delete(fullfile(ofilepath,'..txt'));
delete(fullfile(ofilepath,'...txt'));

 
