function [ discrepancy ] = INcon( S , EAz , Eih , IP , ray_weight )

%% README
%subroutine INcon.m is aimed to calculate the inconsistent ratio of focal
%mechanism solutions 

% INPUT:
% S: n-by-d matrix of selected solutions, where n is the number of selected
% solutions, d indicates six components of each solution's stress tensor.
% EAz: points' azimuth
% Eih: points' zenith
% IP: points' polarity; +1 upward implusive; +11 upward emergent;
% -1 downward implusive; -11 downward emergent
% ray_weight: points' weight

% OUTPUT:
% discrepancy: solutions's discrepancy

SQ = 1/sqrt(2); 
rad = pi/180; 
Az = rad*EAz;
ih = rad*Eih;
n = size(S,1);
NN = size(Az);
discrepancy = zeros(n,1);
for i = 1:n
    S11 = S(i,1);    S12 = S(i,2);    S13 = S(i,3);    S22 = S(i,4);    S23 = S(i,5);    S33 = S(i,6);
    S_matrix = [S11 S12 S13 ; S12 S22 S23 ; S13 S23 S33];
    [V,D] = eig(S_matrix); %#ok<NASGU>
    % p = [V(1,1),V(2,1),V(3,1)];
    b = [V(1,2),V(2,2),V(3,2)];
    t = [V(1,3),V(2,3),V(3,3)];
    for j = 1:NN   
        l = [sin(ih(j))*cos(Az(j)) , sin(ih(j))*sin(Az(j)) , cos(ih(j))];
        l_pt = ( l-(l*b')*b ) / norm( l-(l*b')*b );
        c_angle = l_pt*t';
        if ( norm(l-b) == 0 ) || ( abs(c_angle) == SQ )
            discrepancy(i) = discrepancy(i)+ray_weight(j)/2;
        elseif  (abs(c_angle)>SQ && IP(j)<0) || (abs(c_angle)<SQ && IP(j)>0)
            discrepancy(i) = discrepancy(i)+ray_weight(j);
        else
            discrepancy(i) = discrepancy(i)+0;
        end
    end
end
end
