function [  ] = y_plot_polarity(  )

% plot focal mechanism, polarities, and waveforms

% inputfile = '../Colombia20150310/Colombia20150310_P.dat';
% inputfile = '../Colombia20150310/Colombia20150310_pP.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_pP.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_sP.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_SH.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_sSH.dat';
% inputfile = '../Colombia20150310/Colombia20150310_SH.dat';
% inputfile = '../Colombia20150310/Colombia20150310_sSH.dat';
% inputfile = '../Colombia20150310/Colombia20150310_sP.dat';
% inputfile = '../Colombia20150310/ColombiaCorr_polarity_PF.txt';
inputfile = '../GS_data/20150310205544.56_TA_SV_2nd_polarity.txt';


% phasename = 'SV';

[ stname , EAz , Eih , IP] = textread(inputfile,'%s %f %f %d');
[pathstr, name, ext] = fileparts(inputfile); %#ok<NASGU>
% deal with polarity readings more than NN_threshold
NN=length(IP);     % NN=Total polarity readings

% change to lower hemisphere projection
ind = find(Eih>90);
Eih(ind) = 180-Eih(ind);
EAz(ind) = mod(EAz(ind)+180,360);


% plot parameters
X0 = 0.5; Y0 = 0.5; R0 = 0.25; % Center & Radius of great circle
% R1=0.25; %radius of PTB circle
scrsz = get(0,'ScreenSize');
remin = 1/2*min(scrsz(3:4));


%% temp plot
f1 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f1,'name',['Polarities'],'NumberTitle','off');
 axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;

% plot polarity readings on Schmidt net
FMplotP(EAz,Eih,X0,Y0,R0,IP);

xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);

% textname(EAz,Eih,X0,Y0,R0,stname);
axis off;
axis equal
axis([0 1 0 1]);



end

