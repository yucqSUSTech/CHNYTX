function [ number , S_selected , discrepancy_selected_origin ,discrepancy_selected_jack  ] = grid_sub( EAz , Eih , IP , nzenith , nrotation , ray_weight ,discrepancy_range ,min_number , max_number , jack_knife)

%% README : GRID_SUB
%Calculate each test's solution,such as P,T,B axis and stress matrix S and inconsistency ratio,
%then sort them by inconsistent ratio

% INPUT:
% EAz: points' azimuth
% Eih: points' zenith
% IP: points' polarity; +1 upward implusive; +11 upward emergent;
% -1 downward implusive; -11 downward emergent
% nzenith: number of B axis's zenith test
% nrotation: number of P,T axis's test with a give B axis position
% ray_weight: points' weight
% discrepancy_range: inconsistency ratio within minimum discrepancy and
%                   minimum discrepancy + discrepancy_range will be selected 
% min_number: minimum number of selected solutions
% max_number: maximum number of selected solutions
% jack_knife: jack knife test button 
% 'delete': delete each point one by one;
% 'reverse': reverse each point's polarity one by one
% 'none' or any other symbol : no jack knife test

% OUTPUT:
% number: number of selected solutions
% S_selected: stress matrix of selected solutions, stored in n-by-d matrix
% n equals number,d is the six components of each solution's stress tensor
% discrepancy_selected_origin: inconsistency ratio of each selected solution
% discrepancy_selected_jack: minimum inconsistency ratio of each selected
% solution when jack knife test is executed.


%% Grid search for Focal Mechanism solution
% search step for B-axis in direction and P-T plane in rotation,
% search type: multi_six. B axis's azimuth position is determined by its
% zenith position. for example ,if B axis's zenith equals to ih (ih!=0), then its
% azimuth varies from 0 , 60*dih/ih , 120*dih/ih , ... , to 360-60*dih/ih.
% if ih = 0 ,then its azimuth equals to 0;
dzenith = pi/(2*nzenith);
drotation = pi/(2*nrotation);
nsector = 2*nrotation;
ncircle = nzenith + 1; 
six = 6;
solution_num = (3*ncircle^2-3*ncircle+1)*nrotation; % total solution number

rad = pi/180;
ray_azimuth = EAz*rad;
ray_zenith = Eih*rad;
ray_num = length(IP);  %total point number
ray_weight_o = ray_weight;
IP_o = IP;
%pre_allocation
S = zeros(solution_num,6);
discrepancy = ones(solution_num,ray_num+1);

for jack = 1:(ray_num+1)  
    solution_index = 1; % solution number
    ray_weight = ray_weight_o;
    IP = IP_o;
    if jack > 1
        if strcmp(jack_knife,'delete')  % if jack_knife == delete , then execute jack knife test (delete one point, then change another one )
            ray_weight(jack-1) = 0;
            ray_weight = ray_weight/sum(ray_weight);
        elseif strcmp(jack_knife,'reverse') % if jack_knife == reverse , then execute jack knife test (reverse one point's polarity, then change another one )
            IP(jack-1) = -IP(jack-1);
        else  %no jack knife test
            break;
        end
    end


%% Grid step one by one
for zenith_index = 0:nzenith % loop for zenith of B-axis        
    zenith_b = dzenith*zenith_index;    
    if zenith_index == 0 
        dazimuth = 2*pi; 
    else 
        nazimuth = six*zenith_index;
        dazimuth = 2*pi/nazimuth;
    end    

    for azimuth_b = 0:dazimuth:2*pi-dazimuth % loop for azimuth of B-axis
        
        % unit vector of B-axis
        b = [sin(zenith_b)*cos(azimuth_b) , sin(zenith_b)*sin(azimuth_b) , cos(zenith_b)];
        % normal vectors of initial P,T planes(not in order yet)
        n0 = [sin(azimuth_b) , -cos(azimuth_b) , 0];
        m0 = [-cos(zenith_b)*cos(azimuth_b) , -cos(zenith_b)*sin(azimuth_b) , sin(zenith_b)];
        
        % prelocate the weight sum holder
        positive_sector = zeros(1,nsector); % to sum the weights of events in a sector with positive IP
        negative_sector = zeros(1,nsector); % to sum the weights of events in a sector with negative IP
                
        
        for ray_index = 1:ray_num % loop for all the rays to calculate the sum of weights for rays in each sector of the P-T plane
            
            % direction vector of the ray 
            l = [sin(ray_zenith(ray_index))*cos(ray_azimuth(ray_index)) , sin(ray_zenith(ray_index))*sin(ray_azimuth(ray_index)) , cos(ray_zenith(ray_index))];
            
            if norm(l-b) < 10e-3 %l is close to b
                ratio = -1; 
            else
                l_pt = ( l - (l*b')*b )/norm(l - (l*b')*b);% unit vector of the ray direction projected on P-T plane
                
                lpt_m = l_pt*m0';
                if abs(abs(lpt_m) - 1)<10e-3
                    angle_lpt_m = 0;
                else
                    angle_lpt_m = acos(lpt_m); % angle between l_pt and m0
                end
                
                % in case angle between l_pt and n0 is larger than pi/2 
                if l_pt*n0' < 0
                    angle_lpt_m = pi - angle_lpt_m;
                end
                ratio = angle_lpt_m/drotation;
            end

            % if the ray's direction coincides with the nodal line between two sectors, it's weight will be halved between both sectors
            if floor(ratio) == ceil(ratio)
                
                if ratio == 0 % halved between the first and last sectors
                    if IP(ray_index) > 0
                        positive_sector(1) = positive_sector(1) + ray_weight(ray_index)/2;
                        positive_sector(nrotation) = positive_sector(nrotation) + ray_weight(ray_index)/2;
                    else
                        negative_sector(1) = negative_sector(1) + ray_weight(ray_index)/2;
                        negative_sector(nrotation) = negative_sector(nrotation) + ray_weight(ray_index)/2;
                    end

                elseif ratio == nsector
                    if IP(ray_index) > 0
                        positive_sector(1) = positive_sector(1) + ray_weight(ray_index)/2;
                        positive_sector(nrotation) = positive_sector(nrotation) + ray_weight(ray_index)/2;
                    else
                        negative_sector(1) = negative_sector(1) + ray_weight(ray_index)/2;
                        negative_sector(nrotation) = negative_sector(nrotation) + ray_weight(ray_index)/2;
                    end

                elseif ratio == -1 % l = b
                    if IP(ray_index) > 0
                        positive_sector = positive_sector + ray_weight(ray_index)/nsector;
                    else
                        negative_sector = negative_sector + ray_weight(ray_index)/nsector;
                    end

                else % halved between adjoint sectors
                    sector_index = ratio;
                    if IP(ray_index) > 0
                        positive_sector(sector_index+1) = positive_sector(sector_index+1) + ray_weight(ray_index)/2;
                        positive_sector(sector_index) = positive_sector(sector_index) + ray_weight(ray_index)/2;
                    else
                        negative_sector(sector_index+1) = negative_sector(sector_index+1) + ray_weight(ray_index)/2;
                        negative_sector(sector_index) = negative_sector(sector_index) + ray_weight(ray_index)/2;
                    end
                end

            else

                sector_index = ceil(ratio);
                
                if IP(ray_index)>0
                    positive_sector(sector_index) = positive_sector(sector_index) + ray_weight(ray_index);
                else
                    negative_sector(sector_index) = negative_sector(sector_index) + ray_weight(ray_index); 
                end

            end

        end


        %% rotate sector
        
        for rotation_index = 1:nrotation
            positive_quadrant1 = sum(positive_sector(rotation_index:nrotation+rotation_index-1));
            negative_quadrant1 = sum(negative_sector(rotation_index:nrotation+rotation_index-1));
            positive_quadrant2 = sum( [positive_sector(nrotation+rotation_index:nsector),positive_sector(1:rotation_index-1)] );
            negative_quadrant2 = sum( [negative_sector(nrotation+rotation_index:nsector),negative_sector(1:rotation_index-1)] );
            
            discrepancy_p1 = negative_quadrant1 + positive_quadrant2;
            discrepancy_p2 = positive_quadrant1 + negative_quadrant2;
            rotation_angle = drotation*(rotation_index-1);
            R = [cos(rotation_angle) , -sin(rotation_angle) ; sin(rotation_angle) , cos(rotation_angle)]; % rotation matrix
            
            nm = R*[n0;m0]; n = nm(1,:); m = nm(2,:);		
                        
            % calculate S , P B T and discrepancy:
            if discrepancy_p1 <= discrepancy_p2  %discrepancy_p1+discrepancy_p2=1
                p1 = (n-m)/sqrt(2);
                t1 = (n+m)/sqrt(2);
                
                S(solution_index,1) = t1(1)*t1(1)-p1(1)*p1(1);  %s11
                S(solution_index,2) = t1(1)*t1(2)-p1(1)*p1(2);  %s12
                S(solution_index,3) = t1(1)*t1(3)-p1(1)*p1(3);  %s13
                S(solution_index,4) = t1(2)*t1(2)-p1(2)*p1(2);  %s22
                S(solution_index,5) = t1(2)*t1(3)-p1(2)*p1(3);  %s23
                S(solution_index,6) = t1(3)*t1(3)-p1(3)*p1(3);  %s33
                
                discrepancy(solution_index,jack) = discrepancy_p1; % incosistency ratio
                solution_index = solution_index + 1;
                
            else % P <-> T 
                p2 = (n+m)/sqrt(2);
                t2 = (n-m)/sqrt(2);   
                
                S(solution_index,1) = t2(1)*t2(1)-p2(1)*p2(1);  %s11
                S(solution_index,2) = t2(1)*t2(2)-p2(1)*p2(2);  %s12
                S(solution_index,3) = t2(1)*t2(3)-p2(1)*p2(3);  %s13
                S(solution_index,4) = t2(2)*t2(2)-p2(2)*p2(2);  %s22
                S(solution_index,5) = t2(2)*t2(3)-p2(2)*p2(3);  %s23
                S(solution_index,6) = t2(3)*t2(3)-p2(3)*p2(3);  %s33
                
                discrepancy(solution_index,jack) = discrepancy_p2; % incosistency ratio                
                solution_index = solution_index + 1;
            end
        end   %end of rotation loop
    end   %end of B_azimuth loop
end %end of B_zenith loop

end  %end of jack knife test
      
%% sort by discrepancy
[Sort_discrepancy_jack,IX_jack] = sort(min(discrepancy,[],2)); %choose minimum discrepancy of jack knife test of each solution
Sort_S = zeros(solution_num,6); %prelocation
origin_discrepancy = zeros(solution_num,1);%prelocation
for i = 1:solution_num 
    Sort_S(i,:) = S(IX_jack(i),:);
    origin_discrepancy(i) = discrepancy(IX_jack(i),1); %sort by the order the minimum jack discrepancy, so origin_discrepancy might not in ascending order 
end

%% Choose solutions within the discrepancy range
% minimum = Sort_discrepancy(1);%Lowest inconsistency ratio
minimum = min(discrepancy(:,1));
maximum = minimum+discrepancy_range;
number = 0;
while Sort_discrepancy_jack( number+1 ) <= maximum 
    number = number + 1;
end

%define minimum and maximum number of selected solutions
if number < min_number
    number = min_number;
elseif number > max_number;
    number = max_number;
end    

S_selected = zeros(number,6);%here 6 means six components of stress tensor
discrepancy_selected_origin = zeros(number,1);
discrepancy_selected_jack = zeros(number,1);
for i = 1:number
    discrepancy_selected_origin(i) = origin_discrepancy(i);
    discrepancy_selected_jack(i) = Sort_discrepancy_jack(i);
    S_selected(i,:) = Sort_S(i,:);
end

end


