function [  ] = y_plot_radiationpattern(  )

%
addpath('/Users/Chunquan/Research/Matlab_codes/my_package/y_others');

% sol = [ 30 75  300 145 34  208  335 51   97 24  202 29  0.01 3.9 1.000 ];
% 
% SK1 = sol(1);
% DA1 = sol(2);
% SA1 = sol(3); 
% SK2 = sol(4); 
% DA2 = sol(5); 
% SA2 = sol(6); 
% PAZ = sol(7); 
% PPL = sol(8); 
% TAZ = sol(9); 
% TPL = sol(10); 
% BAZ = sol(11); 
% BPL = sol(12);  
% MDB = sol(13);  
% RMS = sol(14);  
% REL = sol(15); 


% % [SK1, DA1, SA1] = textread('./1stFMS.txt','%f %f %f','commentstyle','shell');
% % [SK1, DA1, SA1] = textread('./2ndFMS.txt','%f %f %f','commentstyle','shell');
% [SK1, DA1, SA1] = textread('./2ndFMS_1.txt','%f %f %f','commentstyle','shell');

% solution of 1st event
% [SK1, DA1, SA1] = deal(144, 27, -149); % first event from CMT
% [SK1, DA1, SA1] = deal(0, 90, -90);
% [SK1, DA1, SA1] = deal(0, 90, 0);
[SK1, DA1, SA1] = deal(35, 80, -9);

% solution of 2nd event
% [SK1, DA1, SA1] = deal(170,10,-120); % best
% [SK1, DA1, SA1] = deal(140,10,-150); % try

% [SK2, DA2, SA2] = auxplane(SK1, DA1, SA1);
[SK2, DA2, SA2] = y_GS_Auxplane(SK1, DA1, SA1);

dtheta = 5;
daz = 5;
theta = 0:dtheta:90;
az = 0:daz:360-daz;
[TK, AZM] = meshgrid(theta,az);
gamma = 0;
sigma = 0.25;


[Gp, Gs, Gsh, Gsv] = rpgen(SK1, DA1, SA1, gamma, sigma, TK, AZM);

theta0 = reshape(TK,[],1);
az0 = reshape(AZM,[],1);
Gp0 = reshape(Gp,[],1);
Gs0 = reshape(Gs,[],1);
Gsh0 = reshape(Gsh,[],1);
Gsv0 = reshape(Gsv,[],1);


% normalization
Gp0 = Gp0/(max(abs(Gp0)));
Gs0 = Gs0/(max(abs(Gs0)));
Gsh0 = Gsh0/(max(abs(Gsh0)));
Gsv0 = Gsv0/(max(abs(Gsv0)));

% for P waves
G0 = Gp0;
titlename = 'P radiation pattern';
% % for SH waves
% G0 = Gsh0;
% titlename = 'SH radiation pattern';
% % % for SV waves
% G0 = Gsv0;
% titlename = 'SV radiation pattern';

%% plot on focal sphere
% plot parameters
X0 = 0.5; Y0 = 0.5; R0 = 0.25; % Center & Radius of great circle
% R1=0.25; %radius of PTB circle
scrsz = get(0,'ScreenSize');
remin = 1/2*min(scrsz(3:4));

f1 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
% set(f1,'name','SH radiation pattern','NumberTitle','off');
set(f1,'name',titlename,'NumberTitle','off');
axes('Position',[0 0 1 1]);
hold on;

%
NN = length(az0);
RAD = pi / 180;
AZP = RAD * az0; 
IHP = RAD * theta0;
rp = R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
xp=X0+rp.*sin(AZP); 
yp=Y0+rp.*cos(AZP);


% plot radiation pattern - interpolated
[XX,YY] = meshgrid(X0-R0:R0/100:X0+R0,Y0-R0:R0/100:Y0+R0);
ZZ = griddata(xp,yp,G0,XX,YY);
surf(XX,YY,ZZ);
shading interp

% % plot radiation pattern - scattered
% msize = 10;
% rsize = msize*abs(G0);
% ind = find(G0<0);
% ind2 = find(G0>=0);
% colors = G0;
% % scatter(xp(ind),yp(ind),msize,colors(ind),'Marker','o');
% % scatter(xp(ind2),yp(ind2),msize,colors(ind2),'Marker','+');
% scatter(xp(ind),yp(ind),rsize(ind),'bo');
% scatter(xp(ind2),yp(ind2),rsize(ind2),'r+');


% h = colorbar('location','eastoutside','position',[0.80 0.3 0.02 0.4]);
% caxis([-1 1]);

axis equal;

% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot3(xs,ys,ones(size(xs)),'k','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot3(xs,ys,ones(size(xs)),'k','LineWidth',2); %--cluster center nodline II
% plot polarity readings on Schmidt net

% FMplotP(az0,theta0,X0,Y0,R0,ip0);
% % FMplotP(EAz,Eih,X0,Y0,R0,IP);

% % P and T axes location on Schmidt net
% RAD = pi / 180;
% CPAZ_one = RAD * PAZ;    CPIH_one = RAD * ( 90 - PPL );
% CTAZ_one = RAD * TAZ;    CTIH_one = RAD * ( 90 - TPL );
% rp = R0 * sqrt(2)*sin(CPIH_one/2);    % Schmidt projection
% rt = R0 * sqrt(2)*sin(CTIH_one/2);    % Schmidt projection
% xp=X0+rp.*sin(CPAZ_one);    yp=Y0+rp.*cos(CPAZ_one);
% xt=X0+rt.*sin(CTAZ_one);    yt=Y0+rt.*cos(CTAZ_one);
% text(xp,yp,ones(size(xp)),'P','color','k','FontSize',16);
% text(xt,yt,ones(size(xp)),'T','color','k','FontSize',16);

xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;

colormap(jet);
y_colorbar(0.03);



end

