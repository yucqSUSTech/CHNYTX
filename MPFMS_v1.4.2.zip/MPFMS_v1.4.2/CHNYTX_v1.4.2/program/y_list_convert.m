function [  ] = y_list_convert(  )

% % %
% inlist = '../GS_data/Colombia20150310_P_pP.dat';
% outlist = '../GS_data/Colombia20150310_P_pP.lst';
% phasename = 'P';
% weight = 1;


% inlist = '../GS_data/Colombia20150310_SH_2nd_polarity_one_PCA.txt';
% outlist = '../GS_data/Colombia20150310_SH_2nd_polarity_one_PCA.txt';
% phasename = 'SH';
% weight = 1;


% inlist = '../GS_data/20150310205544.56_TA_SV_polarity.txt';
% outlist = '../GS_data/SV_TA_2nd_polarity.txt';
% phasename = 'SV';
% weight = 1;

% inlist = '../GS_data/Colombia20150310_SH_sSH.dat';
% outlist = '../GS_data/Colombia20150310_SH_sSH.txt';
% phasename = 'SH';
% weight = 1;


%%
% inlist = '../FMS/Colombia20150310_polarity_subevent1_P.dat';
% outlist = '../FMS/Colombia20150310_polarity_subevent1_P.txt';
% phasename = 'P';
% weight = 1;

% inlist = '../FMS/Colombia20150310_polarity_subevent1_pP.dat';
% outlist = '../FMS/Colombia20150310_polarity_subevent1_pP.txt';
% phasename = 'P';
% weight = 1;

% inlist = '../FMS/Colombia20150310_polarity_subevent1_SH.dat';
% outlist = '../FMS/Colombia20150310_polarity_subevent1_SH.txt';
% phasename = 'SH';
% weight = 1;

% inlist = '../FMS/Colombia20150310_polarity_subevent1_sSH.dat';
% outlist = '../FMS/Colombia20150310_polarity_subevent1_sSH.txt';
% phasename = 'SH';
% weight = 1;

inlist = '../FMS/Colombia20150310_polarity_subevent1_sP.dat';
outlist = '../FMS/Colombia20150310_polarity_subevent1_sP.txt';
phasename = 'SV';

weight = 1;
[stna,eaz,eih,ip] = textread(inlist,'%s %s %s %d');
fid = fopen(outlist,'w'); 
for i = 1:length(stna)
    fprintf(fid,'%s %s %s %+d %s %d\n',stna{i},eaz{i},eih{i},sign(ip(i)),phasename,weight); 
end; 
fclose(fid);


end

