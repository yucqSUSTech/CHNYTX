function [  ] = y_GS_2ndFMS(  )

% Grid search for the FMS of the second event, given the FMS of the first
% event and amplitude ratios of these two events
%

path(path,genpath('/scratch1/yucq-MIT/research/Matlab_codes/seizmo-master/'));


%% Parameters
%Polarity files of the second subevent
Polarityfile = {
    '../GS_data/Colombia20150310_polarity_subevent2_SH.txt';
    '../GS_data/Colombia20150310_polarity_subevent2_SV.txt';
    };

% Ampltiude files of two subevents
Amplitudefile = {
    '../GS_data/Colombia20150310_amplitude_subevent1+2_P.txt';
    '../GS_data/Colombia20150310_amplitude_subevent1+2_SH.txt';
    };

% weight of polarity misfit
weightP = [
    1;
    1;
    ];
% weight of amplitude misfit 
weightA = [
    2;
    0.01;
    ];

% normalize weight
weightP = reshape(weightP/(sum(weightP)+sum(weightA)),[],1);
weightA = reshape(weightA/(sum(weightP)+sum(weightA)),[],1);

% % FMS for the first subevent
% From polarities
[strike1 dip1 rake1] = deal(139, 31, -160);
% % From GCMT solutions
% [strike1 dip1 rake1] = deal(144, 27, -149);

% % % FMS search grids
% % % global search
% dstrike = 5;
% ddip = 5;
% drake = 5;
% % dstrike = 10;
% % ddip = 10;
% % drake = 10;
% strike2 = 0:dstrike:360;
% % strike2 = 0:dstrike:180;
% dip2 = 0:ddip:90;
% % rake2 = -180:drake:180;
% rake2 = 0:drake:360;

% local search
dstrike = 1;
ddip = 1;
drake = 1;
strike2 = 130:dstrike:170;
dip2 = 0:ddip:30;
rake2 = -170:drake:-130;



% for pure double couple FMS
gamma = 0;
sigma = 0.25;


% theoretical amplitude ratio range in log scale
lamprange = [-2 2];

% total misfit range
misfit_range = 0.01;


% % Inconsistent ratio
% incon_range = 0.1;
% min_number = 10;
% max_number = 1000;
% 
% % Amplitude ratio misfit range
% misfit_range = 0.01;


%% load in polarities
for i = 1:length(Polarityfile)

    [stna, EAz, Eih, IP, Wtype, weight] = textread(Polarityfile{i},'%s %f %f %d %s %f','commentstyle','shell');
    
    % change to lower hemisphere projection
    ind = find(Eih>90);
    Eih(ind) = 180-Eih(ind);
    EAz(ind) = mod(EAz(ind)+180,360);
    
    if length(unique(Wtype)) > 1
        fprintf('There should be only one Wavetype in each file\n');
        return;
    end
    P(i).Wmode = Wtype{1};
    P(i).stna = stna';
    P(i).EAz = EAz';
    P(i).Eih = Eih';
    P(i).IP = IP';
    P(i).weight = weight';
    
%     % calculate radiation pattern of the first subevent
%     P(i).G = y_radiationpattern( strike1, dip1, rake1, gamma, sigma, P(i).EAz, P(i).Eih, P(i).Wmode );
end
    

%% load in amplitudes
for i = 1:length(Amplitudefile)
    [stna,EAz,Eih,amp1,amp2,Wtype,weight] = textread(Amplitudefile{i},'%s %f %f %f %f %s %d','commentstyle','shell');
    
    % change to lower hemisphere projection
    ind = find(Eih>90);
    Eih(ind) = 180-Eih(ind);
    EAz(ind) = mod(EAz(ind)+180,360);
    
    if length(unique(Wtype)) > 1
        fprintf('There should be only one Wavetype in each file\n');
        return;
    end
    A(i).Wmode = Wtype{1};
    A(i).stna = stna';
    A(i).EAz = EAz';
    A(i).Eih = Eih';
    A(i).amp1 = amp1';
    A(i).amp2 = amp2';
    A(i).weight = weight';
    A(i).lampratio = log10(abs(A(i).amp1)./abs(A(i).amp2));
    
    % calculate radiation pattern of the first subevent
    A(i).G = y_radiationpattern( strike1, dip1, rake1, gamma, sigma, A(i).EAz, A(i).Eih, A(i).Wmode );
end



misfitP = zeros(length(strike2),length(dip2),length(rake2),length(P)); % for polarity
misfitA = zeros(length(strike2),length(dip2),length(rake2),length(A)); % for amplitude ratios
mratio = zeros(length(strike2),length(dip2),length(rake2),length(A)); % for amplitude ratios
misfitT = zeros(length(strike2),length(dip2),length(rake2),length(A)+length(P)); % for total misfit
for i = 1:length(strike2)
    i
    for j = 1:length(dip2)
        
        for k = 1:length(rake2)
            
            % for polarities
            for m = 1:length(P)
                G = y_radiationpattern( strike2(i), dip2(j), rake2(k), gamma, sigma, P(m).EAz, P(m).Eih, P(m).Wmode );
                iscon = G.*P(m).IP>0;
                misfitP(i,j,k,m) = 1 - sum(iscon.*P(m).weight) ./ sum(P(m).weight);
            end
            
            % for amplitude
            for m = 1:length(A)
                G = y_radiationpattern( strike2(i), dip2(j), rake2(k), gamma, sigma, A(m).EAz, A(m).Eih, A(m).Wmode );
                lGratio = log10(abs(A(m).G)./abs(G));
                
                % constrain theoretical amplitude ratio range
                ind1 = find(lGratio<lamprange(1));
                lGratio(ind1) = lamprange(1);
                ind2 = find(lGratio>lamprange(2));
                lGratio(ind2) = lamprange(2);
                
                % amplitude ratio difference
                ldratio = lGratio - A(m).lampratio;
                
                % remove DC component
                mratio(i,j,k,m) = mean(ldratio);
                ldratio = ldratio-mratio(i,j,k,m);
                %             ldratio = detrend(ldratio,'constant');
                
                misfitA(i,j,k,m) = mean(abs(ldratio));
            end               
        end
    end
end
    
% normalize misfitP and misfitA
for m = 1:size(misfitP,4)
    tmp = squeeze(misfitP(:,:,:,m));
    imax = max(tmp(:));
    imin = min(tmp(:));
    irange = imax - imin;
    misfitP(:,:,:,m)  = misfitP(:,:,:,m)/irange;
end
for m = 1:size(misfitA,4)
    tmp = squeeze(misfitA(:,:,:,m));
    imax = max(tmp(:));
    imin = min(tmp(:));
    irange = imax - imin;
    misfitA(:,:,:,m)  = misfitA(:,:,:,m)/irange;
end

% total misfit
for i = 1:size(misfitP,4)
    misfitT(:,:,:,i) = misfitP(:,:,:,i)*weightP(i);
end
for i = 1:size(misfitA,4)
    misfitT(:,:,:,size(misfitP,4)+i) = misfitA(:,:,:,i)*weightA(i);
end
misfitT = sum(misfitT,4);
% normalize misfitT
misfitT = misfitT/(max(misfitT(:))-min(misfitT(:)));


[c,idx] = min(misfitT(:));
ind = find(misfitT<=c+misfit_range);

[ia1,ib1,ic1] = ind2sub(size(misfitT),idx);
[ia,ib,ic] = ind2sub(size(misfitT),ind);

% [ia1,ib1,ic1] = deal(3,9,29);

%% PLOT focal mechanism solutions
% plot parameters
X0 = 0.5; Y0 = 0.5; R0 = 0.25; % Center & Radius of great circle
scrsz = get(0,'ScreenSize');
remin = 1/2*min(scrsz(3:4));
%%
figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
axes('Position',[0 0 1 1]);
hold on;
FMcircle(X0,Y0,R0);

% plot nodal planes for the first event (reference event)
SK1 = strike1;
DA1 = dip1;
SA1 = rake1;
[ SK2, DA2, SA2 ] = auxplane( SK1, DA1, SA1  );
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'k-','linewidth',2); %--Nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'k-','linewidth',2); %--Nodline II

% % plot all possible nodal planes for the second event
% for i = 1:length(ia)
%     SK1 = strike2(ia(i));
%     DA1 = dip2(ib(i));
%     SA1 = rake2(ic(i));
%     [ SK2, DA2, SA2 ] = auxplane( SK1, DA1, SA1  );
%     [xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'y-','linewidth',2); %--Nodline I
%     [xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'y-','linewidth',2); %--Nodline II
% end

% plot nodal planes for the minimum misfitA solution 
SK1 = strike2(ia1);
DA1 = dip2(ib1);
SA1 = rake2(ic1);
[ SK2, DA2, SA2 ] = auxplane( SK1, DA1, SA1  );
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r-','linewidth',2); %--Nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r-','linewidth',2); %--Nodline II

xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off

return;

%% plot misfitA along three cross sections across the best solution
% Amplitude ratio misfit
RAD = pi / 180;
for m = 1:size(misfitA,4)
    figure
    subplot(2,2,1)
    imagesc(dip2,rake2,squeeze(misfitA(ia1,:,:,m))');
    hold on;
    plot(dip2(ib1),rake2(ic1),'wp');
    xlabel('Dip');
    ylabel('Rake');
    colorbar;
    title(A(m).Wmode);
    subplot(2,2,2)
    imagesc(strike2,rake2,squeeze(misfitA(:,ib1,:,m))');
    hold on;
    plot(strike2(ia1),rake2(ic1),'wp');
    xlabel('Strike');
    ylabel('Rake');
    colorbar;
    subplot(2,2,3)
    imagesc(strike2,dip2,squeeze(misfitA(:,:,ic1,m))');
    hold on;
    plot(strike2(ia1),dip2(ib1),'wp');
    xlabel('Strike');
    ylabel('Dip');
    colorbar;
    
    subplot(2,2,4)
    hold on;
    FMcircle(X0,Y0,R0);
    [xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r-','linewidth',2); %--Nodline I
    [xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r-','linewidth',2); %--Nodline II    
    xlim([X0-2*R0,X0+2*R0]);
    ylim([Y0-2*R0,Y0+2*R0]);
    axis off
       
    [ G ] = y_radiationpattern( strike2(ia1), dip2(ib1), rake2(ic1), gamma, sigma, A(m).EAz, A(m).Eih, A(m).Wmode );
    lGratio = log10(abs(A(m).G)./abs(G));
    % constrain theoretical amplitude ratio range
    ind1 = find(lGratio<lamprange(1));
    lGratio(ind1) = lamprange(1);
    ind2 = find(lGratio>lamprange(2));
    lGratio(ind2) = lamprange(2);
    
    % remove mean
    lGratio = lGratio -  mratio(ia1,ib1,ic1);

    % amplitude ratio difference
    ldratio = lGratio - A(m).lampratio;
    
    AZP = RAD * A(m).EAz;
    IHP = RAD * A(m).Eih;
    rp = R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
    xp=X0+rp.*sin(AZP);
    yp=Y0+rp.*cos(AZP);
    scatter(xp,yp,20,ldratio,'o','filled');
    h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
    % caxis([-log10(2) log10(2)]);
    ylabel(h,'Misfit of Log_{10}(A1/A2)');
    
    axis equal;
end

% Polarity misfit
for m = 1:size(misfitP,4)
    figure
    subplot(2,2,1)
    imagesc(dip2,rake2,squeeze(misfitP(ia1,:,:,m))');
    hold on;
    plot(dip2(ib1),rake2(ic1),'wp');
    xlabel('Dip');
    ylabel('Rake');
    colorbar;
    title(P(m).Wmode);
    subplot(2,2,2)
    imagesc(strike2,rake2,squeeze(misfitP(:,ib1,:,m))');
    hold on;
    plot(strike2(ia1),rake2(ic1),'wp');
    xlabel('Strike');
    ylabel('Rake');
    colorbar;
    subplot(2,2,3)
    imagesc(strike2,dip2,squeeze(misfitP(:,:,ic1,m))');
    hold on;
    plot(strike2(ia1),dip2(ib1),'wp');
    xlabel('Strike');
    ylabel('Dip');
    colorbar;
end

% Total misfit
figure
subplot(2,2,1)
imagesc(dip2,rake2,squeeze(misfitT(ia1,:,:))');
hold on;
plot(dip2(ib1),rake2(ic1),'wp');
xlabel('Dip');
ylabel('Rake');
colorbar;
title('Total misfit');
subplot(2,2,2)
imagesc(strike2,rake2,squeeze(misfitT(:,ib1,:))');
hold on;
plot(strike2(ia1),rake2(ic1),'wp');
xlabel('Strike');
ylabel('Rake');
colorbar;
subplot(2,2,3)
imagesc(strike2,dip2,squeeze(misfitT(:,:,ic1))');
hold on;
plot(strike2(ia1),dip2(ib1),'wp');
xlabel('Strike');
ylabel('Dip');
colorbar;


% output best fit solution
fid = fopen('./2ndFMS.txt','w');
fprintf(fid,'#Strike Dip Rake\n');
fprintf(fid,'%.1f %.1f %.1f\n',strike2(ia1), dip2(ib1), rake2(ic1));
fclose(fid);
end

