function Grid_point_test(inputfile,NN_threshold,nzenith,nrotation,w2,dangle,discrepancy_range,min_number,max_number,max_cluster_num,RA_range,jack_knife,DIS_good,DIS_bad,RMS_good)

%% README
% INPUT:
% inputfile: dat file, format
%            stname	EAz		Eih		IP
% the defination of all other input parameters can be found in para.m


%% read inputfile
[ stname , EAz , Eih , IP] = textread(inputfile,'%s %f %f %d');
% [pathstr, name, ext, versn] = fileparts(inputfile); %#ok<NASGU>
[pathstr, name, ext] = fileparts(inputfile); %#ok<NASGU>
% deal with polarity readings more than NN_threshold
NN=length(IP);     % NN=Total polarity readings
if NN < NN_threshold
    disp('Reading number is less than: ');disp(NN_threshold);
    return;
end
% change ray-upward points to ray-downward points, also remove data points,
% whose Eih are NaN.
temp = 1;
for i=1:NN
    if ~isnan(Eih(i)) % in case of Eih(i) is NaN. delete Eih(i) = NaN points
        if Eih(i)>90
            Eih(i)=180-Eih(i);  EAz(i)=EAz(i)+180;
            if EAz(i)>360,    EAz(i)=EAz(i)-360;    end
        end
        EAz_temp(temp,1) = EAz(i);        Eih_temp(temp,1) = Eih(i);        IP_temp(temp,1) = IP(i);
        temp = temp + 1;
    end
end
EAz = EAz_temp; Eih = Eih_temp; IP = IP_temp;


%% Calculate and store parameters of selected solutions
% calculate each points' weight. Subroutine Weight.m
[ray_weight] = Weight(EAz , Eih , IP , dangle , w2); 
% grid search for all solutions, choose selected solutions, and calculate their stress matrix and discrepancy
[ number , S_selected , discrepancy_selected_origin, discrepancy_selected_jack ] ...
    = grid_sub( EAz , Eih , IP , nzenith , nrotation , ray_weight ,discrepancy_range ,...
    min_number , max_number,jack_knife); 

disp('Lowest inconsistency ratio:'); disp(min(discrepancy_selected_origin));
disp('Number of selected solutions: ');  disp(number);

% Output FM solutions
fdo = fopen([pathstr,'/', name,'.gt'],'w');   
fprintf(fdo,'%s\n','   selected solutions:');
if strcmp(jack_knife,'delete')
    fprintf(fdo,'%s\n','SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB MDB_jack_del');
elseif strcmp(jack_knife,'reverse')
    fprintf(fdo,'%s\n','SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB MDB_jack_rev');
else
    fprintf(fdo,'%s\n','SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB');
end
%subroutine Parameters.m: calculate parameters from stress matrix
[ SK1 DA1 SA1  SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL ] = Parameters( S_selected );

  
%% Calculate and store parameters of cluster centers
%subroutine Cluster.m;CID provides a set of n indexes indicating cluster membership for each point. NR is the number of observations in each cluster. CENTERS is a matrix, where each row corresponds to a cluster center.
[cid,nr,centers] = Cluster(S_selected,max_cluster_num,RA_range);
%subroutine Parameters.m: calculate parameters from stress matrix
[ CSK1 CDA1 CSA1  CSK2 CDA2 CSA2  CPAZ CPPL CTAZ CTPL CBAZ CBPL ] = Parameters( centers );
%subroutine INcon.m :calculate discrepancy of mean solution
center_discrepancy = INcon( centers,EAz,Eih,IP,ray_weight); 

NUM = size(centers,1); %number of cluster centers
Reliability = nr/sum(nr); % calculate the reliability of each cluster center, by the number of solutions in each cluster
[Sort_Reliability,INDEX] = sort(Reliability,'descend'); %sort Reliability, descend
RMS = zeros(1,NUM);%root mean square of rotation angle


%% polt and output selected solutions and all cluster centers

% plot parameters
X0 = 100; Y0 = 100; R0 = 60; % Center & Radius of great circle
R1=30; %radius of PTB circle
clf('reset');
figure(1);
% text station name
textname(EAz,Eih,X0,Y0,R0,stname);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
for i = 1:number
    [xs,ys]=FMnodline(SK1(i),DA1(i),X0,Y0,R0);  plot(xs,ys,'y-'); %--Nodline I
    [xs,ys]=FMnodline(SK2(i),DA2(i),X0,Y0,R0);  plot(xs,ys,'y-'); %--Nodline II
    if strcmp(jack_knife,'delete') || strcmp(jack_knife,'reverse')
        FMS=[SK1(i) DA1(i) SA1(i)  SK2(i) DA2(i) SA2(i)  PAZ(i) PPL(i) TAZ(i) TPL(i) BAZ(i) BPL(i) discrepancy_selected_origin(i) discrepancy_selected_jack(i)];
        fprintf(fdo,'%3.0f%3.0f%5.0f %3.0f%3.0f%5.0f %4.0f%3.0f %4.0f%3.0f %4.0f%3.0f  %1.2f %1.2f\n',FMS);
    else
        FMS=[SK1(i) DA1(i) SA1(i)  SK2(i) DA2(i) SA2(i)  PAZ(i) PPL(i) TAZ(i) TPL(i) BAZ(i) BPL(i) discrepancy_selected_origin(i)];
        fprintf(fdo,'%3.0f%3.0f%5.0f %3.0f%3.0f%5.0f %4.0f%3.0f %4.0f%3.0f %4.0f%3.0f  %1.2f\n',FMS);      
    end
end 
%plot and output cluster centers
for i = 1:NUM
    % define color of cluster center nodline
    if i == 1 %the cluster center with most number of selected solutions (highest reliability)
        color = 'r-';
    elseif i == 2
        color = 'g-'; 
    else
        color = 'b-';
    end    
    j = INDEX(i);
    [xs,ys]=FMnodline(CSK1(j),CDA1(j),X0,Y0,R0);  plot(xs,ys,color,'LineWidth',2); %--cluster center nodline I
    [xs,ys]=FMnodline(CSK2(j),CDA2(j),X0,Y0,R0);  plot(xs,ys,color,'LineWidth',2); %--cluster center nodline II
    ind = find(cid==j);
    S_cluster = S_selected(ind,:); %#ok<FNDSB>
    RMS(j) = RA_stdev( S_cluster ); % subroutine RA_stdev.m , calculate rotation angle stdev in each cluster
    FMS=[CSK1(j) CDA1(j) CSA1(j)  CSK2(j) CDA2(j) CSA2(j)  CPAZ(j) CPPL(j) CTAZ(j) CTPL(j) CBAZ(j) CBPL(j) center_discrepancy(j) RMS(j) Reliability(j)];
    fprintf(fdo,'\n%s%d%s\n','   cluster center ',i,':');
    fprintf(fdo,'%s\n','SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB  RMS  REL');
    fprintf(fdo,'%3.0f%3.0f%5.0f %3.0f%3.0f%5.0f %4.0f%3.0f %4.0f%3.0f %4.0f%3.0f  %1.2f %1.1f %1.3f \n',FMS);
end

% % classify the quality of the solution  A , B and C, and label it
% RMS_max = max(RMS);
% min_dis = min(discrepancy_selected_origin);
% if (min_dis < DIS_good) && (NUM == 1) && (RMS_max < RMS_good)
%     text(X0+0.8*R0,Y0-0.8*R0,'A','color','r','FontSize',24 , 'Fontname', 'Arial' , 'Fontweight', 'bold' , 'FontAngle' , 'normal'); 
% elseif (min_dis > DIS_bad) || (NUM > 1) 
%     text(X0+0.8*R0,Y0-0.8*R0,'C','color','r','FontSize',24 , 'Fontname', 'Arial' , 'Fontweight', 'bold' , 'FontAngle' , 'normal');
% else
%     text(X0+0.8*R0,Y0-0.8*R0,'B','color','r','FontSize',24 , 'Fontname', 'Arial' , 'Fontweight', 'bold' , 'FontAngle' , 'normal');
% end
% 
% Minimum = num2str(min_dis,'%1.2f');
% text( X0+0.65*R0 , Y0-0.95*R0 ,'\psi','FontSize',18, 'FontAngle' , 'italic' );
% text( X0+0.74*R0 , Y0-0.99*R0 ,' _m_i_n','FontSize',12 );
% text( X0+0.81*R0 , Y0-0.95*R0 ,['  = ', Minimum],'FontSize',16 );

% plot polarity readings on Schmidt net
FMplotP(EAz,Eih,X0,Y0,R0,IP);
% title(name,'fontsize',12);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis('equal');  
axis off;
% saveas(gcf,[pathstr,'/',name,'.jpg'],'jpg');  
% print('-r600','-djpeg',[pathstr,'/',name,'.jpg']);
print('-r300','-dpdf',[pathstr,'/',name,'.pdf']);
hold off;


%% plot and output the most probable cluster center (has maximum number of selected solutions)
figure(2);
% plot great circle
% textname(EAz,Eih,X0,Y0,R0,stname);
% hold on;
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines for the most probable cluster center
[xs,ys]=FMnodline(CSK1(INDEX(1)),CDA1(INDEX(1)),X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(CSK2(INDEX(1)),CDA2(INDEX(1)),X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% plot polarity readings on Schmidt net
FMplotP(EAz,Eih,X0,Y0,R0,IP);
% text P and T axes on Schmidt net
RAD = pi / 180;
CPAZ_one = RAD * CPAZ(INDEX(1));    CPIH_one = RAD * ( 90 - CPPL(INDEX(1)) );
CTAZ_one = RAD * CTAZ(INDEX(1));    CTIH_one = RAD * ( 90 - CTPL(INDEX(1)) );
rp = R0 * sqrt(2)*sin(CPIH_one/2);    % Schmidt projection
rt = R0 * sqrt(2)*sin(CTIH_one/2);    % Schmidt projection
xp=X0+rp.*sin(CPAZ_one);    yp=Y0+rp.*cos(CPAZ_one);
xt=X0+rt.*sin(CTAZ_one);    yt=Y0+rt.*cos(CTAZ_one);
text(xp,yp,'P','color','k','FontSize',16);
text(xt,yt,'T','color','k','FontSize',16);
% title(name,'fontsize',12);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis('equal');
axis off;
% saveas(gcf,[pathstr,'/',name,'.one.jpg'],'jpg');  
% print('-r600','-djpeg',[pathstr,'/',name,'.one.jpg']);
print('-r300','-dpdf',[pathstr,'/',name,'.one.pdf']);
hold off;


%%  Plot all possible P, B & T axes
figure(3);
FMplotPTB( name,PAZ,PPL,TAZ,TPL,BAZ,BPL,cid,NUM,X0,Y0,R1 );%subroutine PlotPTB.m
axis('equal');
axis off;
% saveas(gcf,[pathstr, '/',name,'.PTB.jpg'],'jpg');
% print('-r600','-djpeg',[pathstr,'/',name,'.PTB.jpg']);
print('-r300','-dpdf',[pathstr,'/',name,'.PTB.pdf']);
hold off;
fclose all;
% close all;


end
