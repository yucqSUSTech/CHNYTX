function [  ] = y_fit_waveforms_GUI(  )

% using Gaussian functions to approximate two subevents to fit waveforms
% Using GUI


%% figure and text setting
ftsize = 12;
phtextsize = 16; % phase text size
ftname = 'Arial';
set(0,'defaultaxesfontsize',ftsize);
set(0,'defaulttextfontsize',ftsize);
set(0,'DefaultUicontrolUnits','normalized');
set(0,'DefaultUicontrolFontsize',ftsize);
set(0,'DefaultUicontrolFontname',ftname);

bcolor = 0.9*[1 1 1];
color_show = [0 0 0];
color_selected = [1 0 0];
color_wig_up = [0 0 0];
color_wig_dn = 0.7*[1 1 1];
color_theo = 'm';
msize_theo = 5;
linewidth_show = 0.5;
linewidth_selected = 1;


%%
para.datadir = '/media/yucq2/Data0/Colombia_20150310/Fromserver/Phases/SH/';
para.listname = 'list_t_box_comb_one_PCA_S.txt';
para.outdir = '/media/yucq2/Data0/Colombia_20150310/Fromserver/FitPCA_SH/';

[lists, phtt, phtshift, phT, polarity, stnm, netwk, phrayp] = textread(fullfile(para.datadir,para.listname),'%s %f %f %f %d %s %s %f','commentstyle','shell');

para.lists = lists;
para.phT = phT;
para.polarity = polarity;
para.stnm = stnm;
para.netwk = netwk;

% define parameters
para.ievent = 1;
para.nevent = length(para.lists);

fit = [];
%% plot interface setup
f1                      =	figure('Toolbar','figure','Units','normalized','Position',[.1 .1 .8 .8]);
handle.hax              =	axes('pos', [.2 .1 .6 .8]);

%% plot panel
plot_panel              =	uipanel('parent', f1,'title', 'Plot', 'Position', [0.01 .35 .15 .55]);

% initial plot
                            uicontrol(plot_panel,'String','Ini(i)','callback',@callback_iniplot,'Position',[.2 .90 .6 .1]);
                            uicontrol(plot_panel,'Style','text','String','Lowf','Position',[.0 .50 .4 .04]);
handle.h_filter_fl      =   uicontrol(plot_panel,'Style','edit','String','0.02','Position',[.4 .50 .4 .04],'BackgroundColor',bcolor);
                            uicontrol(plot_panel,'Style','text','String','Highf','Position',[.0 .45 .4 .04]);
handle.h_filter_fh      =   uicontrol(plot_panel,'Style','edit','String','2','Position',[.4 .45 .4 .04],'BackgroundColor',bcolor);
                            uicontrol(plot_panel,'Style','text','String','Order','Position',[.0 .40 .4 .04]);
handle.h_order          =   uicontrol(plot_panel,'Style','edit','String','2','Position',[.4 .40 .4 .04],'BackgroundColor',bcolor);


%% Adjust panel
adjust_panel            =   uipanel('parent', f1,'title', 'Adjust', 'pos', [0.85 .65 .15 .3]);
                            uicontrol(adjust_panel,'Style','text','String','Gauss 1','Position',[.1 .9 .8 .1 ]);
handle.h_A1             =   uicontrol(adjust_panel,'Style','edit','String','1','Position',[.05 .8 .3 .1],'BackgroundColor',bcolor);
handle.h_sigma1         =   uicontrol(adjust_panel,'Style','edit','String','1','Position',[.35 .8 .3 .1],'BackgroundColor',bcolor);
handle.h_c1             =   uicontrol(adjust_panel,'Style','edit','String','0','Position',[.65 .8 .3 .1],'BackgroundColor',bcolor);
                            uicontrol(adjust_panel,'Style','text','String','Gauss 2','Position',[.1 .65 .8 .1 ]);
handle.h_A2             =   uicontrol(adjust_panel,'Style','edit','String','1','Position',[.05 .55 .3 .1],'BackgroundColor',bcolor);
handle.h_sigma2         =   uicontrol(adjust_panel,'Style','edit','String','1','Position',[.35 .55 .3 .1],'BackgroundColor',bcolor);
handle.h_c2             =   uicontrol(adjust_panel,'Style','edit','String','5','Position',[.65 .55 .3 .1],'BackgroundColor',bcolor);

handle.h_cal            =   uicontrol(adjust_panel,'Style','push','String','Update','callback',@callback_calculate,'Position',[.1 .4 .8 .1 ],'BackgroundColor',bcolor);

handle.h_twinl          =   uicontrol(adjust_panel,'Style','edit','String','-10','Position',[.1 .25 .4 .1],'BackgroundColor',bcolor);
handle.h_twinr          =   uicontrol(adjust_panel,'Style','edit','String','10','Position',[.5 .25 .4 .1],'BackgroundColor',bcolor);
handle.h_delta          =   uicontrol(adjust_panel,'Style','edit','String','0.1','Position',[.3 .15 .4 .1],'BackgroundColor',bcolor);
handle.h_dy             =   uicontrol(adjust_panel,'Style','edit','String','0.0','Position',[.3 .05 .4 .1],'BackgroundColor',bcolor);

%% Event panel
event_panel             =   uipanel('parent', f1,'title', 'Event', 'pos', [0.85 .3 .15 .3]);
handle.h_preevent       =   uicontrol(event_panel,'Style','push','String','Pre','callback',@callback_preevent,'Position',[.1 .6 .8 .3],'BackgroundColor',bcolor);
handle.h_nextevent      =   uicontrol(event_panel,'Style','push','String','Next','callback',@callback_nextevent,'Position',[.1 .2 .8 .3],'BackgroundColor',bcolor);


%% Save panel
save_panel              =   uipanel('parent', f1,'title', 'Event', 'pos', [0.85 .1 .15 .15]);
handle.h_save           =   uicontrol(save_panel,'Style','push','String','Save','callback',@callback_save,'Position',[.1 .1 .8 .8],'BackgroundColor',bcolor);


%%
    function callback_iniplot(h,dummy)
               
        % load in data
        [hd,data]=irdsac(fullfile(para.datadir,para.lists{para.ievent}));
        
        para.elat = hd.evla;
        para.elon = hd.evlo;
        para.edep = hd.evdp;
        para.slat = hd.stla;
        para.slon = hd.stlo;
        para.dist = hd.gcarc;
        para.az = hd.az;
        para.staname = deblank(reshape(hd.kstnm,1,[]));
        para.netwk = deblank(reshape(hd.knetwk,1,[]));
               
        % check whether data exist
        if exist(fullfile(para.outdir,[para.netwk,'.',para.staname,'.mat']),'file')
            tmp = load(fullfile(para.outdir,[para.netwk,'.',para.staname,'.mat']));
            fit = tmp.fit;
            callback_setpara(h,dummy)            
        end
        
%         % update parameters
%         callback_updatepara (h,dummy);            
            
        time = linspace(hd.b,hd.e,hd.npts)-hd.o - para.phT(para.ievent); 
        
        para.time_raw = time;
        para.data_raw = data;
        
        callback_calculate(h,dummy);  
        
    end

    function callback_calculate(h,dummy)
        
        callback_updatepara(h,dummy);
        
        % cut data
        para.data = interp1(para.time_raw,para.data_raw,para.time,'linear',0);
%         % filter data
%         para.data = filtering(para.data,para.delta,para.fl,para.fh,para.order); % band pass filtering
        
        para.A0 = max(para.data)-min(para.data);
        para.data = para.data/para.A0;
        
        % calculate theoretical summed results
        para.syn1=para.A1*gaussmf(para.time,[para.sigma1 para.c1]);
        para.syn2=para.A2*gaussmf(para.time,[para.sigma2 para.c2]);
        para.syn = para.syn1+para.syn2;
        
%         % filter synthetic data       
%         para.syn = filtering(para.syn,para.delta,para.fl,para.fh,para.order); % band pass filtering
              
        % shift in y axis
        para.syn = para.syn + para.dy;
        
        callback_plot(h,dummy)
    end


    function callback_preevent(h,dummy)
        para.ievent = para.ievent-1;
        if para.ievent < 1
            para.ievent = 1;
        end
        callback_iniplot(h,dummy)
    end

    function callback_nextevent(h,dummy)
        para.ievent = para.ievent+1;
        if para.ievent > para.nevent
            para.ievent = para.nevent;
        end
        callback_iniplot(h,dummy)
    end

        
    function callback_plot(h,dummy)
        
        cla(handle.hax,'reset');
        box on;
        hold(handle.hax,'on');
        
        % plot data
        plot(para.time,para.data,'k-');        
        
        % plot theoretical results        
        plot(para.time,para.syn,'r-');
        
        xlim([para.time(1) para.time(end)]);
        ylim([-1 1]);
        title([para.netwk,'.',para.staname,' Az=',num2str(para.az,'%.1f'),' Dist=',num2str(para.dist,'%.1f')]);
        
    end

        
    function callback_updatepara(h,dummy)
        para.A1 = str2num(get(handle.h_A1,'String'));
        para.sigma1 = str2num(get(handle.h_sigma1,'String'));
        para.c1 = str2num(get(handle.h_c1,'String'));
        para.A2 = str2num(get(handle.h_A2,'String'));
        para.sigma2 = str2num(get(handle.h_sigma2,'String'));
        para.c2 = str2num(get(handle.h_c2,'String'));
        
        para.twinl = str2num(get(handle.h_twinl,'String'));
        para.twinr = str2num(get(handle.h_twinr,'String'));
        para.delta = str2num(get(handle.h_delta,'String'));
        para.time = para.twinl:para.delta:para.twinr;
        
        para.fl = str2num(get(handle.h_filter_fl,'String'));
        para.fh = str2num(get(handle.h_filter_fh,'String'));
        para.order = str2num(get(handle.h_order,'String'));
        para.dy = str2num(get(handle.h_dy,'String'));
    end
        
    function callback_save(h,dummy)
        
        if exist('fit','var')
            clear fit;
        end
        
        fit.amp1 = para.A0*para.A1;
        fit.amp2 = para.A0*para.A2;
        fit.A0 = para.A0;
        fit.gauss1 = para.A0*para.syn1;        
        fit.gauss2 = para.A0*para.syn2;         
        fit.gaussSynthetic = para.A0*para.syn;       
        fit.timeVector = para.time;
        fit.tau = para.delta;        
        fit.centroid1 = 0;
        fit.centroid2 = para.c2-para.c1;
        fit.c1 = para.c1;
        fit.c2 = para.c2;
        fit.sigma1 = para.sigma1;
        fit.sigma2 = para.sigma2;
        
        fit.elat = para.elat;
        fit.elon = para.elon;
        fit.edep = para.edep;
        fit.slat = para.slat;
        fit.slon = para.slon;
        fit.dist = para.dist;
        fit.az = para.az;
            
        fit.fl = para.fl;
        fit.fh = para.fh;
        fit.order = para.order;
        
        fit.dy = para.dy;
        
        fit.staname = para.staname;
        fit.netwk = para.netwk;
        fit.polarity = para.polarity(para.ievent);
        
        save(fullfile(para.outdir,[fit.netwk,'.',fit.staname,'.mat']),'fit');
        
    end


    function callback_setpara(h,dummy)
        if isfield(fit,'A0')
            if isfield(fit,'amp1') 
                set(handle.h_A1,'String',num2str(fit.amp1/fit.A0));
            end
            if isfield(fit,'amp2') 
                set(handle.h_A2,'String',num2str(fit.amp2/fit.A0));
            end
        end
        
        if isfield(fit,'sigma1')
            set(handle.h_sigma1,'String',num2str(fit.sigma1));
        end
        if isfield(fit,'sigma2')
            set(handle.h_sigma2,'String',num2str(fit.sigma2));
        end
        if isfield(fit,'c1')
            set(handle.h_c1,'String',num2str(fit.c1));
        end
        if isfield(fit,'c2')
            set(handle.h_c2,'String',num2str(fit.c2));
        end                    
        
        if isfield(fit,'fl')
            set(handle.h_filter_fl,'String',num2str(fit.fl));
        end 
        if isfield(fit,'fh')
            set(handle.h_filter_fh,'String',num2str(fit.fh));
        end 
        if isfield(fit,'order')
            set(handle.h_order,'String',num2str(fit.order,'%.0f'));
        end 
        
        if isfield(fit,'dy')
            set(handle.h_dy,'String',num2str(fit.dy));
        end 
        
        
    end

end

