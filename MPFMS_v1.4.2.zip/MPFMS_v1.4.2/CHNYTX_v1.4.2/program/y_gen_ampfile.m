function [  ] = y_gen_ampfile(  )


% %% For P wave
% FitPCAdir = '/media/yucq2/Data0/Colombia_20150310/Fromserver/FitPCA';   
% listname = 'list_z_FitPCA_P.txt';
%     
% em = set_vmodel_v2('iasp91');
% np = 100;
% 
% phase = 'P';
% weight = 1;
% 
% fid = fopen('../GS_data/GS_amplitudes_P.txt','w');
% 
% lists = textread(fullfile(FitPCAdir,listname),'%s','commentstyle','shell');
% 
% for i = 1:length(lists)
%     
%     load(fullfile(FitPCAdir,lists{i}));
%        
%     stna{i} = fit.staname;
%     stla(i) = fit.slat;
%     stlo(i) = fit.slon;
%     evla(i) = fit.elat;
%     evlo(i) = fit.elon;
%     evdp(i) = fit.edep;
%     amp1(i) = fit.amp1;
%     amp2(i) = fit.amp2;
%     dist(i) = fit.dist;
%     az(i) = fit.az;
%     ampratio(i) = fit.amp1/fit.amp2;
% end
%    
% [ rayp, du ] = y_get_rayp_p_P_Pdiff_interp( evdp(1), em, dist, np );
%     
% % calculate take-off angle
% vp = interp1db(evdp(1),em.z,em.vp);
% theta = asind(rayp*vp/(em.re-evdp(1)));
% theta = mod(theta.*du,180);
% 
% for i = 1:length(lists)
%     fprintf(fid,'%s %f %f %e %e %s %d\n',stna{i},az(i),theta(i),amp1(i),amp2(i),phase,weight);
% end
% fclose(fid);



%%
FitPCAdir = '/media/yucq2/Data0/Colombia_20150310/Fromserver/FitPCA_SH';   
listname = 'list_t_FitPCA_SH.txt';

em = set_vmodel_v2('iasp91');
np = 100;

phase = 'SH';
weight = 1;

fid = fopen('../GS_data/GS_amplitudes_SH.txt','w');

lists = textread(fullfile(FitPCAdir,listname),'%s','commentstyle','shell');

for i = 1:length(lists)
    
    load(fullfile(FitPCAdir,lists{i}));
       
    stna{i} = fit.staname;
    stla(i) = fit.slat;
    stlo(i) = fit.slon;
    evla(i) = fit.elat;
    evlo(i) = fit.elon;
    evdp(i) = fit.edep;
    amp1(i) = fit.amp1;
    amp2(i) = fit.amp2;
    dist(i) = fit.dist;
    az(i) = fit.az;
    ampratio(i) = fit.amp1/fit.amp2;
end
[ rayp, du ] = y_get_rayp_s_S_Sdiff_interp( evdp(1), em, dist, np );
    
% calculate take-off angle
vs = interp1db(evdp(1),em.z,em.vs);
theta = asind(rayp*vs/(em.re-evdp(1)));
theta = mod(theta.*du,180);

for i = 1:length(lists)
    fprintf(fid,'%s %f %f %e %e %s %d\n',stna{i},az(i),theta(i),amp1(i),amp2(i),phase,weight);
end
fclose(fid);

end

