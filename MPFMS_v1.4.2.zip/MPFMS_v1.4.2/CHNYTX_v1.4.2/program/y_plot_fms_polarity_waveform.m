function [  ] = y_plot_fms_polarity_waveform(  )

% plot focal mechanism, polarities, and waveforms

% inputfile = '../Colombia20150310/Colombia20150310_P.dat';
% inputfile = '../Colombia20150310/Colombia20150310_pP.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_pP.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_sP.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_SH.dat';
% inputfile = '../Colombia20150310/Colombia20150310_fromPCA_sSH.dat';
inputfile = '../Colombia20150310/Colombia20150310_SH.dat';
% inputfile = '../Colombia20150310/Colombia20150310_sSH.dat';
% inputfile = '../Colombia20150310/Colombia20150310_sP.dat';
% inputfile = '../Colombia20150310/ColombiaCorr_polarity_PF.txt';


eventdir = {
%     '/media/yucq2/Data0/Colombia_20150310/Fromserver/CorrectedGlobal/';
%     '/media/yucq2/Data0/Colombia_20150310/Fromserver/CorrectedBrasil/';
%     '/media/yucq2/Data0/Colombia_20150310/sac/20150310205544.56/';
%     '/media/yucq2/Data0/Colombia_20150310/Fromserver/Phases/P';
%     '/media/yucq2/Data0/Colombia_20150310/Fromserver/Phases/pP';
%     '/media/yucq2/Data0/Colombia_20150310/Fromserver/Phases/sP';
    '/media/yucq2/Data0/Colombia_20150310/Fromserver/Phases/SH';
%     '/media/yucq2/Data0/Colombia_20150310/Fromserver/Phases/sSH';
    };

phasefiles = {
%     'list_z_box_comb_one_PCA_P.txt';
%     'list_z_box_comb_one_PCA_pP.txt';
%     'list_z_box_comb_one_PCA_sP.txt';
    'list_t_box_comb_one_PCA_S.txt';
%     'list_t_box_comb_one_PCA_sS.txt';
    };

phasename = {
%     'P';
%     'pP';
%     'sP';
    'SH';
%     'sSH';
    };


[ stname , EAz , Eih , IP] = textread(inputfile,'%s %f %f %d');
[pathstr, name, ext] = fileparts(inputfile); %#ok<NASGU>
% deal with polarity readings more than NN_threshold
NN=length(IP);     % NN=Total polarity readings

% change ray-upward points to ray-downward points, also remove data points,
% whose Eih are NaN.
temp = 1;
for i=1:NN
    if ~isnan(Eih(i)) % in case of Eih(i) is NaN. delete Eih(i) = NaN points
        if Eih(i)>90
            Eih(i)=180-Eih(i);  EAz(i)=EAz(i)+180;
            if EAz(i)>360,    EAz(i)=EAz(i)-360;    end
        end
        EAz_temp(temp,1) = EAz(i);        Eih_temp(temp,1) = Eih(i);        IP_temp(temp,1) = IP(i);
        temp = temp + 1;
    end
end
EAz_all = EAz_temp; Eih_all = Eih_temp; IP_all = IP_temp;


% plot nodal lines for the most probable cluster center
sol = [ 30 75  300 145 34  208  335 51   97 24  202 29  0.01 3.9 1.000 ];
SK1 = sol(1);
DA1 = sol(2);
SA1 = sol(3); 
SK2 = sol(4); 
DA2 = sol(5); 
SA2 = sol(6); 
PAZ = sol(7); 
PPL = sol(8); 
TAZ = sol(9); 
TPL = sol(10); 
BAZ = sol(11); 
BPL = sol(12);  
MDB = sol(13);  
RMS = sol(14);  
REL = sol(15); 

% plot parameters
X0 = 0.5; Y0 = 0.5; R0 = 0.25; % Center & Radius of great circle
% R1=0.25; %radius of PTB circle
scrsz = get(0,'ScreenSize');
remin = 1/2*min(scrsz(3:4));

% P and T axes location on Schmidt net
RAD = pi / 180;
CPAZ_one = RAD * PAZ;    CPIH_one = RAD * ( 90 - PPL );
CTAZ_one = RAD * TAZ;    CTIH_one = RAD * ( 90 - TPL );
rp = R0 * sqrt(2)*sin(CPIH_one/2);    % Schmidt projection
rt = R0 * sqrt(2)*sin(CTIH_one/2);    % Schmidt projection
xp=X0+rp.*sin(CPAZ_one);    yp=Y0+rp.*cos(CPAZ_one);
xt=X0+rt.*sin(CTAZ_one);    yt=Y0+rt.*cos(CTAZ_one);


% %% temp plot
% f1 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
% set(f1,'name',['Polarities'],'NumberTitle','off');
% hbb = axes('Position',[0 0 1 1]);
% hold on;
% % plot great circle
% FMcircle(X0,Y0,R0); %axis equal;
% % plot nodal lines
% [xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
% [xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% % plot polarity readings on Schmidt net
% 
% FMplotP(EAz_all,Eih_all,X0,Y0,R0,IP_all);
% % FMplotP(EAz,Eih,X0,Y0,R0,IP);
% 
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
% xlim([X0-2*R0,X0+2*R0]);
% ylim([Y0-2*R0,Y0+2*R0]);
% axis off;
% 
% textname(EAz_all,Eih_all,X0,Y0,R0,stname);
% 
% axis([0 1 0 1]);
% 
% return;

%% plot waveforms

timewin = [-10 10];
delta = 0.1;
itime = reshape(timewin(1):delta:timewin(2),[],1);

ph = struct([]);

for k = 1:length(eventdir)
    
    for kk = 1:length(phasefiles)
        if exist(fullfile(eventdir{k},phasefiles{kk}),'file')
            [lists, phtt, phtshift, phT, polarity, stnm, netwk, phrayp] = textread(fullfile(eventdir{k},phasefiles{kk}),'%s %f %f %f %d %s %s %f','commentstyle','shell');
            
            if ~isfield(ph,'tr')
                num = 0;
            else
                num = length(ph(kk).tr);
            end
            for i = 1:length(stnm)
                stname_tmp = [netwk{i},'.',stnm{i}];
                ind = find(strcmpi(stname_tmp,stname));
                if isempty(ind)
                    continue;
                end
                
%                 ind2 = find(abs(IP(ind))==1 | abs(IP(ind))==5);
%                 if isempty(ind2)
%                     continue;
%                 end
                idx = ind(1);
                num = num + 1;
                EAz_P(num) = EAz(idx);
                Eih_P(num) = Eih(idx);
                stname_P{num} = stname_tmp;
                
                [hd,data] = irdsac(fullfile(eventdir{k},lists{i}));
                
                time = reshape(linspace(hd.b,hd.e,hd.npts)-hd.o-phT(i),[],1);
                idata = interp1(time,data,itime,'linear',0);
                
                iA0 = max(idata)-min(idata);
                if iA0 == 0
                    iA0 = 1;
                end
                ph(kk).tr(num).data = idata/iA0;
                ph(kk).tr(num).time = itime;
                ph(kk).tr(num).A0 = iA0;
                ph(kk).tr(num).EAz = EAz(idx);
                ph(kk).tr(num).Eih = Eih(idx);
                ph(kk).tr(num).stname = stname_tmp;
                
            end
            
        end
    end
end
    

%% Plotting

for i = 1:length(phasefiles)

    f1 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
    set(f1,'name',[phasename{i},' polarities and waveforms'],'NumberTitle','off');
    hbb = axes('Position',[0 0 1 1]);
    % text station name
    % textname(EAz,Eih,X0,Y0,R0,stname);
    hold on;
    % plot great circle
    FMcircle(X0,Y0,R0); %axis equal;
    % plot nodal lines
    [xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
    [xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
    % plot polarity readings on Schmidt net
    
    FMplotP(EAz_all,Eih_all,X0,Y0,R0,IP_all);
    % FMplotP(EAz,Eih,X0,Y0,R0,IP);
    
    text(xp,yp,'P','color','k','FontSize',16);
    text(xt,yt,'T','color','k','FontSize',16);
    xlim([X0-2*R0,X0+2*R0]);
    ylim([Y0-2*R0,Y0+2*R0]);
    axis off;
    
    textname(EAz_P,Eih_P,X0,Y0,R0,stname_P);
    % textname(EAz_pP,Eih_pP,X0,Y0,R0,stname_pP);
    
    axis([0 1 0 1]);
    hold(hbb,'on');
    plot_bb_waveform(hbb, [ph(i).tr.EAz], [ph(i).tr.Eih], X0, Y0, R0, ph(i).tr );

    axis equal
end


end

