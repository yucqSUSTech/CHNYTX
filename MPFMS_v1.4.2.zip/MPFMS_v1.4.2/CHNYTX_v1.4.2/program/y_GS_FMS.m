function [  ] = y_GS_FMS(  )

% Grid search for double-couple focal mechanism solutions
% 
% Chuquan Yu, 04/13/2015

path(path,genpath('/scratch1/yucq-MIT/research/Matlab_codes/seizmo-master/cmt'));

%%
datadir = '../GS_data';
dataid = '*.lst';

% load in parameters
para = y_GS_para;

% plot parameters
X0 = 0.5; Y0 = 0.5; R0 = 0.25; % Center & Radius of great circle
scrsz = get(0,'ScreenSize');
remin = 1/2*min(scrsz(3:4));


%%
events = dir(fullfile(datadir,dataid));
nevent = length(events);
for i = 1:nevent
    
    if ~exist(fullfile(datadir,events(i).name),'file')
        continue;
    end
    
    [a,b,c] = fileparts(events(i).name);
    eventname = [a,b];
    
    % read in data
    [stna, EAz, Eih, IP, Wtype, weight] = textread(fullfile(datadir,events(i).name),'%s %f %f %d %s %f','commentstyle','shell');
    
    % reshape to horizontal arrays
    stna = stna';
    EAz = EAz';
    Eih = Eih';
    IP = IP';
    Wtype = Wtype';
    weight = weight';
    
    % change to lower hemisphere projection
    ind = find(Eih>90);
    Eih(ind) = 180-Eih(ind);
    EAz(ind) = mod(EAz(ind)+180,360);
    
    
    % sort data by Wave modes
    Wtype = upper(Wtype);
    [Wmode,ia,ic] = unique(Wtype);
    W = struct;
    for j = 1:length(Wmode)
        ind = find(ic==j);
        W(j).Wmode = Wmode{j};
        W(j).stna = stna{ind};
        W(j).EAz = EAz(ind);
        W(j).Eih = Eih(ind);
        W(j).IP = IP(ind);
        W(j).weight = weight(ind);
    end   
    
    Incon = zeros(length(para.strike),length(para.dip),length(para.rake));
    for j = 1:length(para.strike)
        j
        for k = 1:length(para.dip)
            
            for l = 1:length(para.rake)
                
                for m = 1:length(W)
                    G = y_radiationpattern( para.strike(j), para.dip(k), para.rake(l), para.gamma, para.sigma, W(m).EAz, W(m).Eih, W(m).Wmode );
                    
                    W(m).iscon = G.*W(m).IP>0;                    
                end
                
                Incon(j,k,l) = 1 - sum(([W.iscon].*[W.weight])) ./ sum([W.weight]);
                
            end
        end
    end
    
    % find minimum Inconsistent ratio 
    [cmin,idx] = min(Incon(:));
    
    [ia,ib,ic] = ind2sub(size(Incon),idx);    
    
    % plot focal mechanism solutions
    figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
    axes('Position',[0 0 1 1]);
    hold on;
    FMcircle(X0,Y0,R0);
    axis equal;
    
    % plot nodal planes
    SK1 = para.strike(ia(1));
    DA1 = para.dip(ib(1));
    SA1 = para.rake(ic(1));
    [ SK2, DA2, SA2 ] = y_GS_Auxplane( SK1, DA1, SA1  );
    
    [xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r-'); %--Nodline I
    [xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r-'); %--Nodline II
    
    % plot P polarity only
    ind = find(strcmpi(Wtype,'P'));
    FMplotP(EAz(ind),Eih(ind),X0,Y0,R0,IP(ind));
    
    
    % t,p,b given by [value,plunge,azimuth]
    [t,p,b]=sdr2tpb(SK1,DA1,SA1);
    if p(2) < 0
        p = -p;
    end
    if t(2) < 0
        t = -t;
    end
    if b(2) < 0
        b = -b;
    end
    % output best solution
    FMS = [SK1 DA1 SA1  SK2 DA2 SA2  p(3) p(2) t(3) t(2) b(3) b(2) cmin];
    fdo = fopen(fullfile(datadir,[eventname,'.one']),'w');
    fprintf(fdo,'#SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL MISFIT\n');
    fprintf(fdo,'%3.0f %3.0f %5.0f %3.0f %3.0f %5.0f %4.0f %3.0f %4.0f %3.0f %4.0f %3.0f %1.2f\n',FMS);
    fclose(fdo);
    
    
    
    
%     % find Inconsistent ratios within given range
%     [c,ind] = sort(Incon(:),'ascend');
%     incon_min = c(1); 
%     ind2 = find(c<=incon_min+para.incon_range);
%     if length(ind2) < para.min_number
%         ind2 = 1:para.min_number;
%     elseif length(ind2) > para.max_number
%         ind2 = 1:para.max_number;
%     end
%     idx = ind(ind2);       
%     
%     [ia,ib,ic] = ind2sub(size(Incon),idx);    
%     
%     % plot focal mechanism solutions
%     figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
%     axes('Position',[0 0 1 1]);
%     hold on;
%     FMcircle(X0,Y0,R0);
%     axis equal;
            
%     % plot nodal lines
%     for j = 1:length(ia)
%         SK1 = para.strike(ia(j));
%         DA1 = para.dip(ib(j));
%         SA1 = para.rake(ic(j));        
%         [ SK2, DA2, SA2 ] = y_GS_Auxplane( SK1, DA1, SA1  );
%         
%         [xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r-'); %--Nodline I
%         [xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r-'); %--Nodline II
% %         if strcmp(jack_knife,'delete') || strcmp(jack_knife,'reverse')
% %             FMS=[SK1(i) DA1(i) SA1(i)  SK2(i) DA2(i) SA2(i)  PAZ(i) PPL(i) TAZ(i) TPL(i) BAZ(i) BPL(i) discrepancy_selected_origin(i) discrepancy_selected_jack(i)];
% %             fprintf(fdo,'%3.0f%3.0f%5.0f %3.0f%3.0f%5.0f %4.0f%3.0f %4.0f%3.0f %4.0f%3.0f  %1.2f %1.2f\n',FMS);
% %         else
% %             FMS=[SK1(i) DA1(i) SA1(i)  SK2(i) DA2(i) SA2(i)  PAZ(i) PPL(i) TAZ(i) TPL(i) BAZ(i) BPL(i) discrepancy_selected_origin(i)];
% %             fprintf(fdo,'%3.0f%3.0f%5.0f %3.0f%3.0f%5.0f %4.0f%3.0f %4.0f%3.0f %4.0f%3.0f  %1.2f\n',FMS);
% %         end
%     end
    
    
%     % plot P polarity only
%     ind = find(strcmpi(Wtype,'P'));
%     FMplotP(EAz(ind),Eih(ind),X0,Y0,R0,IP(ind));
    
end             
                    





end

