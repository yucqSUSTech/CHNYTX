function [ next_CN ] = NextCN( centers ,RA_range )

%% README
%this function is aimed to calculate next cluster centers' number with pre-cluster centers
%if the rotation angle between two centers is less than RA_range,
%then next_CN = CN - 1; else, next_CN = CN

% INPUT:
% centers: cluster centers
% RA_range: threshold value for combining 'close' clusters.

% OUTPUT:
% next_CN: number of next cluster centers

rad = pi/180;
CN = size(centers,1); %number of centers
next_CN = CN;
for i = 1:CN  
    C11 = centers(i,1);    C12 = centers(i,2);    C13 = centers(i,3);    C22 = centers(i,4);    C23 = centers(i,5);    C33 = centers(i,6);
    C_matrix = [C11 C12 C13 ; C12 C22 C23 ; C13 C23 C33];
    [C_V,C_D] = eig(C_matrix); %#ok<NASGU>
    C_p = [C_V(1,1),C_V(2,1),C_V(3,1)];
    C_b = [C_V(1,2),C_V(2,2),C_V(3,2)];
    C_t = cross(C_p,C_b);
    for j = i+1:CN
        D11 = centers(j,1);    D12 = centers(j,2);    D13 = centers(j,3);    D22 = centers(j,4);    D23 = centers(j,5);    D33 = centers(j,6);
        D_matrix = [D11 D12 D13 ; D12 D22 D23 ; D13 D23 D33];
        [V,D] = eig(D_matrix); %#ok<NASGU>
        D_p = [V(1,1),V(2,1),V(3,1)];
        D_b = [V(1,2),V(2,2),V(3,2)];
        D_t = cross(D_p,D_b);
        % find the rotation angle between D and C
        [ array ] = sort([ D_p*C_p', D_t*C_t' , D_b*C_b' ],'descend');
        trA = array(1)+abs(array(2)+array(3));
        c_RA = (trA-1)/2;  %trA = 1 + 2*cos(rotation_angle)  
        RA = acos(c_RA)/rad;
        if RA < RA_range
            next_CN = CN - 1;
            return;
        end
    end
end

end
