function [ x,y ] = FMnodline(SK,DA,X0,Y0,R0)

RAD = pi/180; %deg2rad
SK = RAD*SK;
DA = RAD*DA;

num = 36;
d_angle = pi/num;
x = zeros(1,num+1);
y = zeros(1,num+1);
for i = 1:num+1
    n0 = [ cos(SK) , sin(SK) , 0 ];
    m0 = [ sin(pi/2-DA)*cos(pi/2+SK) , sin(pi/2-DA)*sin(pi/2+SK) , cos(pi/2-DA) ];
    angle = (i-1)*d_angle;
    R = [cos(angle) , sin(angle) ; -sin(angle) , cos(angle)];%rotation matrix R
    nm = R*[n0;m0]; 
    n = nm(1,:);%unit vector of each point on the nodline
    Az = atan2( n(2) , n(1) );
    ih = atan2( sqrt(n(1)^2+n(2)^2) , n(3) );
    
    r= R0*sqrt(2)*sin(ih/2);%Equal area(Schmidt) projection
    x(i) = X0 + r*sin(Az);
    y(i) = Y0 + r*cos(Az);
end

end
 