function FMcircle(X0,Y0,R0) 
alpha=0:pi/200:2*pi;
x=X0+R0*cos(alpha);
y=Y0+R0*sin(alpha);
plot(x,y,'-k','Linewidth',2)
% axis equal;
hold on;
%-- draw short bars on the circle 
BB=0.1*R0;
XL = X0 - R0 - BB; XL1 = X0 - R0; XR = X0 + R0; XR1 = X0 + R0 + BB;
YU = Y0 + R0 + BB; YU1 = Y0 + R0; YD = Y0 - R0; YD1 = Y0 - R0 - BB;
XL0 = X0 - BB / 2; XR0 = X0 + BB / 2; YD0 = Y0 - BB / 2; YU0 = Y0 + BB / 2;
XNX = X0 - BB / 2; YNY = YU - BB / 2;
line ([XL ,XL1],[Y0 ,Y0 ],'color','k');  line ([XR ,XR1],[Y0 ,Y0 ],'color','k');
line ([X0 ,X0 ],[YD ,YD1],'color','k');  line ([X0 ,X0 ],[YU ,YU1],'color','k');
% line ([XL0,XR0],[Y0 ,Y0 ],'color','k');  line ([X0 ,X0 ],[YD0,YU0],'color','k');
line ([X0 ,XNX],[YU ,YNY],'color','k');
line ([XL0,XR0],[YU0,YD0],'color','k');  line ([XL0,XR0],[YD0,YU0],'color','k');
% xN = X0;
% yN = Y0 + R0 + 0.15*R0;
% text(xN,yN,'N','color','k','FontSize',18 , 'Fontname', 'Arial' , 'Fontweight', 'bold' , 'FontAngle' , 'Oblique');   %--Plot N
end
 